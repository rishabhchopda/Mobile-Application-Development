package com.example.unitrade;

import android.content.Context;
import android.view.*;
import android.widget.*;

import java.util.ArrayList;

public class ChatAdapter extends BaseAdapter {

    Context context;
    ArrayList<MessageModel> list;
    String myEmail;

    public ChatAdapter(Context c, ArrayList<MessageModel> l, String me) {
        context = c;
        list = l;
        myEmail = me;
    }

    public int getCount() { return list.size(); }
    public Object getItem(int i) { return list.get(i); }
    public long getItemId(int i) { return i; }

    public View getView(int i, View v, ViewGroup parent) {

        MessageModel m = list.get(i);

        if (m.sender.equals(myEmail)) {
            v = LayoutInflater.from(context).inflate(R.layout.item_chat_right, parent, false);
        } else {
            v = LayoutInflater.from(context).inflate(R.layout.item_chat_left, parent, false);
        }

        TextView msg = v.findViewById(R.id.tvMsg);
        TextView time = v.findViewById(R.id.tvTime);

        msg.setText(m.message);
        time.setText(m.time);

        return v;
    }
}