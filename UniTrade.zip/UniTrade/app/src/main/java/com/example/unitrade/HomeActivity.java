package com.example.unitrade;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.*;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class HomeActivity extends AppCompatActivity {

    DrawerLayout drawer;
    NavigationView navView;
    Toolbar toolbar;

    @Override
    protected void attachBaseContext(Context newBase) {
        String lang = LocaleHelper.getLanguage(newBase);
        super.attachBaseContext(LocaleHelper.setLocale(newBase, lang));
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_home);

        // INIT
        drawer = findViewById(R.id.drawer_layout);
        navView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        // DRAWER TOGGLE
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this,
                drawer,
                toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close
        );

        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navView.setNavigationItemSelectedListener(this::handleMenu);

        // ================= CARD CLICK EVENTS =================

        // BUY
        findViewById(R.id.cardBuy).setOnClickListener(v ->
                startActivity(new Intent(this, BuyActivity.class)));

        // SELL
        findViewById(R.id.cardSell).setOnClickListener(v ->
                startActivity(new Intent(this, SellActivity.class)));

        // LOST & FOUND (COMING SOON)
        findViewById(R.id.cardLost).setOnClickListener(v ->
                startActivity(new Intent(this, LostFoundActivity.class)));

        // EVENTS (COMING SOON)
        findViewById(R.id.cardEvents).setOnClickListener(v ->
                startActivity(new Intent(this, EventsActivity.class)));
    }

    // ================= DRAWER MENU =================

    private boolean handleMenu(@NonNull MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.nav_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
        }
        else if (id == R.id.nav_dashboard) {
            startActivity(new Intent(this, MyProductsActivity.class));
        }
        else if (id == R.id.nav_messages) {
            startActivity(new Intent(this, MessagesActivity.class));
        }
        else if (id == R.id.nav_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
        }
        else if (id == R.id.nav_logout) {
            new SessionManager(this).logout();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }

        drawer.closeDrawers();
        return true;
    }
}