package com.example.unitrade;

import android.content.Context;
import android.view.*;
import android.widget.*;

import java.util.ArrayList;

public class ProductListAdapter extends BaseAdapter {

    Context context;
    ArrayList<String> names, prices;

    public ProductListAdapter(Context c, ArrayList<String> n, ArrayList<String> p) {
        context = c;
        names = n;
        prices = p;
    }

    public int getCount() { return names.size(); }
    public Object getItem(int i) { return names.get(i); }
    public long getItemId(int i) { return i; }

    public View getView(int i, View v, ViewGroup parent) {

        if (v == null) {
            v = LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_2, parent, false);
        }

        TextView t1 = v.findViewById(android.R.id.text1);
        TextView t2 = v.findViewById(android.R.id.text2);

        t1.setText(names.get(i));
        t2.setText("₹ " + prices.get(i));

        return v;
    }
}