package com.example.unitrade;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "UniTrade.db", null, 3); // version updated
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // USERS TABLE
        db.execSQL("CREATE TABLE users(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "email TEXT UNIQUE," +
                "password TEXT," +
                "image TEXT)");

        // PRODUCTS TABLE
        db.execSQL("CREATE TABLE products(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "email TEXT," +
                "name TEXT," +
                "price TEXT," +
                "description TEXT," +
                "category TEXT," +
                "image TEXT)");

        // MESSAGES TABLE
        db.execSQL("CREATE TABLE messages(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "sender TEXT," +
                "receiver TEXT," +
                "message TEXT," +
                "time TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS products");
        db.execSQL("DROP TABLE IF EXISTS messages");
        onCreate(db);
    }

    // ================= USERS =================

    public boolean insertUser(String name, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("email", email);
        cv.put("password", password);
        cv.put("image", "");

        return db.insert("users", null, cv) != -1;
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery(
                "SELECT * FROM users WHERE email=? AND password=?",
                new String[]{email, password}
        );

        return c.getCount() > 0;
    }

    public Cursor getUser(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM users WHERE email=?", new String[]{email});
    }

    public void updateProfile(String email, String name, String image) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("image", image);

        db.update("users", cv, "email=?", new String[]{email});
    }

    // ================= PRODUCTS =================

    public boolean insertProduct(String email, String name, String price,
                                 String desc, String category, String image) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("email", email);
        cv.put("name", name);
        cv.put("price", price);
        cv.put("description", desc);
        cv.put("category", category);
        cv.put("image", image);

        return db.insert("products", null, cv) != -1;
    }

    public Cursor getAllProducts() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM products", null);
    }

    public Cursor getProductsByCategory(String category) {
        SQLiteDatabase db = this.getReadableDatabase();

        if (category.equals("All")) {
            return getAllProducts();
        }

        return db.rawQuery(
                "SELECT * FROM products WHERE category=?",
                new String[]{category}
        );
    }

    public Cursor getUserProducts(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM products WHERE email=?",
                new String[]{email}
        );
    }

    public void deleteProduct(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete("products", "id=?", new String[]{String.valueOf(id)});
    }

    public void updateProduct(int id, String name, String price,
                              String desc, String category, String image) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("price", price);
        cv.put("description", desc);
        cv.put("category", category);
        cv.put("image", image);

        db.update("products", cv, "id=?", new String[]{String.valueOf(id)});
    }

    // ================= MESSAGES =================

    // SEND MESSAGE
    public boolean sendMessage(String sender, String receiver,
                               String message, String time) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put("sender", sender);
        cv.put("receiver", receiver);
        cv.put("message", message);
        cv.put("time", time);

        return db.insert("messages", null, cv) != -1;
    }

    // GET CHAT BETWEEN TWO USERS
    public Cursor getChat(String user1, String user2) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM messages WHERE (sender=? AND receiver=?) OR (sender=? AND receiver=?) ORDER BY id ASC",
                new String[]{user1, user2, user2, user1}
        );
    }

    // GET INBOX USERS (DISTINCT)
    public Cursor getInboxUsers(String currentUser) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT DISTINCT CASE " +
                        "WHEN sender=? THEN receiver " +
                        "ELSE sender END AS user " +
                        "FROM messages WHERE sender=? OR receiver=?",
                new String[]{currentUser, currentUser, currentUser}
        );
    }
}