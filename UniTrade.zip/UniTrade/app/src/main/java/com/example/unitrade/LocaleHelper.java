package com.example.unitrade;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;

import java.util.Locale;

public class LocaleHelper {

    public static Context setLocale(Context context, String lang) {

        Locale locale = new Locale(lang);
        Locale.setDefault(locale);

        Configuration config = new Configuration();
        config.setLocale(locale);

        return context.createConfigurationContext(config);
    }

    public static void saveLanguage(Context context, String lang) {
        SharedPreferences prefs =
                context.getSharedPreferences("Settings", Context.MODE_PRIVATE);
        prefs.edit().putString("lang", lang).apply();
    }

    public static String getLanguage(Context context) {
        SharedPreferences prefs =
                context.getSharedPreferences("Settings", Context.MODE_PRIVATE);
        return prefs.getString("lang", "en");
    }
}