package com.example.unitrade;

import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.*;

import java.util.ArrayList;

public class MyProductsActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    DBHelper db;
    SessionManager session;

    ArrayList<Integer> ids = new ArrayList<>();
    ArrayList<String> names = new ArrayList<>();
    ArrayList<String> prices = new ArrayList<>();
    ArrayList<String> descs = new ArrayList<>();
    ArrayList<String> images = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_products);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db = new DBHelper(this);
        session = new SessionManager(this);

        loadProducts();
    }

    private void loadProducts() {

        ids.clear(); names.clear(); prices.clear(); descs.clear(); images.clear();

        Cursor c = db.getUserProducts(session.getEmail());

        if (c.moveToFirst()) {
            do {
                ids.add(c.getInt(0));
                names.add(c.getString(2));
                prices.add(c.getString(3));
                descs.add(c.getString(4));
                images.add(c.getString(5));
            } while (c.moveToNext());
        }

        MyProductAdapter adapter = new MyProductAdapter(this, ids, names, prices, descs, images);
        recyclerView.setAdapter(adapter);
    }
}