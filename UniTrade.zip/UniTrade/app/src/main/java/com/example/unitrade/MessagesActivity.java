package com.example.unitrade;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MessagesActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<String> users = new ArrayList<>();
    DBHelper db;
    SessionManager session;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_messages);

        listView = findViewById(R.id.listView);
        db = new DBHelper(this);
        session = new SessionManager(this);

        loadInbox();

        listView.setOnItemClickListener((p, v, pos, id) -> {
            Intent i = new Intent(this, ChatActivity.class);
            i.putExtra("user", users.get(pos));
            startActivity(i);
        });
    }

    private void loadInbox() {
        users.clear();

        Cursor c = db.getInboxUsers(session.getEmail());
        if (c.moveToFirst()) {
            do {
                users.add(c.getString(0));
            } while (c.moveToNext());
        }

        listView.setAdapter(new InboxAdapter(this, users));
    }
}