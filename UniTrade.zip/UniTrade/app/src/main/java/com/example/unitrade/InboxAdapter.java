package com.example.unitrade;

import android.content.Context;
import android.view.*;
import android.widget.*;

import java.util.ArrayList;

public class InboxAdapter extends BaseAdapter {

    Context context;
    ArrayList<String> users;

    public InboxAdapter(Context c, ArrayList<String> u) {
        context = c;
        users = u;
    }

    public int getCount() { return users.size(); }
    public Object getItem(int i) { return users.get(i); }
    public long getItemId(int i) { return i; }

    public View getView(int i, View v, ViewGroup parent) {

        if (v == null)
            v = LayoutInflater.from(context).inflate(R.layout.item_user, parent, false);

        TextView name = v.findViewById(R.id.tvUser);
        name.setText(users.get(i));

        return v;
    }
}