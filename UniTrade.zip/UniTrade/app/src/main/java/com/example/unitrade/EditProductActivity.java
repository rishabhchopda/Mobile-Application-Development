package com.example.unitrade;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class EditProductActivity extends AppCompatActivity {

    ImageView img;
    EditText name, price, desc;
    Spinner category;
    Button update, change;

    String imagePath = "";
    int id;
    int PICK = 1;

    DBHelper db;

    String[] categories = {
            "Electronics",
            "Books",
            "Clothes",
            "Furniture",
            "Sports",
            "Other"
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_edit_product);

        // Initialize
        img = findViewById(R.id.img);
        name = findViewById(R.id.name);
        price = findViewById(R.id.price);
        desc = findViewById(R.id.desc);
        category = findViewById(R.id.spCategory);
        update = findViewById(R.id.update);
        change = findViewById(R.id.change);

        db = new DBHelper(this);

        // SET CATEGORY DROPDOWN
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                categories
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category.setAdapter(adapter);

        // GET DATA FROM INTENT
        Intent i = getIntent();

        id = i.getIntExtra("id", 0);
        String n = i.getStringExtra("name");
        String p = i.getStringExtra("price");
        String d = i.getStringExtra("desc");
        String c = i.getStringExtra("category");
        imagePath = i.getStringExtra("image");

        // SET DATA
        name.setText(n);
        price.setText(p);
        desc.setText(d);

        // SET CATEGORY SELECTED
        for (int j = 0; j < categories.length; j++) {
            if (categories[j].equals(c)) {
                category.setSelection(j);
                break;
            }
        }

        // LOAD IMAGE SAFELY
        if (imagePath != null && !imagePath.equals("")) {
            try {
                img.setImageURI(Uri.parse(imagePath));
            } catch (Exception e) {
                img.setImageResource(android.R.drawable.ic_menu_gallery);
            }
        }

        // CHANGE IMAGE
        change.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("image/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, PICK);
        });

        // UPDATE PRODUCT
        update.setOnClickListener(v -> {

            db.updateProduct(
                    id,
                    name.getText().toString(),
                    price.getText().toString(),
                    desc.getText().toString(),
                    category.getSelectedItem().toString(),
                    imagePath
            );

            Toast.makeText(this, "Product Updated", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    @Override
    protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);

        if (r == PICK && c == RESULT_OK && d != null) {

            Uri uri = d.getData();

            try {
                getContentResolver().takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                );
            } catch (Exception e) {
                e.printStackTrace();
            }

            img.setImageURI(uri);
            imagePath = uri.toString();
        }
    }
}