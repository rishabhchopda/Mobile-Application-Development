package com.example.unitrade;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.*;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class ProfileActivity extends AppCompatActivity {

    ImageView profileImage;
    EditText name;
    TextView email;
    Button update, logout, changeImage;

    String imagePath = "";
    DBHelper db;
    SessionManager session;

    int PICK_IMAGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> finish());

        // Views
        profileImage = findViewById(R.id.profileImage);
        name = findViewById(R.id.etName);
        email = findViewById(R.id.tvEmail);
        update = findViewById(R.id.btnUpdate);
        logout = findViewById(R.id.btnLogout);
        changeImage = findViewById(R.id.btnChangeImage);

        db = new DBHelper(this);
        session = new SessionManager(this);

        loadUser();

        // Pick Image (UPDATED FIX)
        changeImage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("image/*");
            intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, PICK_IMAGE);
        });

        // Update Profile
        update.setOnClickListener(v -> {
            db.updateProfile(session.getEmail(), name.getText().toString(), imagePath);
            Toast.makeText(this, "Profile Updated", Toast.LENGTH_SHORT).show();
        });

        // Logout
        logout.setOnClickListener(v -> {
            session.logout();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void loadUser() {
        Cursor c = db.getUser(session.getEmail());

        if (c != null && c.moveToFirst()) {
            name.setText(c.getString(1));
            email.setText(c.getString(2));

            // SAFE IMAGE LOAD
            if (c.getColumnCount() > 4) {
                imagePath = c.getString(4);

                if (imagePath != null && !imagePath.equals("")) {
                    try {
                        Uri uri = Uri.parse(imagePath);
                        profileImage.setImageURI(uri);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    // IMAGE RESULT HANDLING (FIXED)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {

            Uri uri = data.getData();

            try {
                // Persist permission (IMPORTANT FIX)
                getContentResolver().takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                );
            } catch (Exception e) {
                e.printStackTrace();
            }

            profileImage.setImageURI(uri);
            imagePath = uri.toString();
        }
    }
}