package com.example.unitrade;

import android.content.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyProductAdapter extends RecyclerView.Adapter<MyProductAdapter.ViewHolder> {

    Context context;
    ArrayList<Integer> ids;
    ArrayList<String> names, prices, descs, images;

    public MyProductAdapter(Context context,
                            ArrayList<Integer> ids,
                            ArrayList<String> names,
                            ArrayList<String> prices,
                            ArrayList<String> descs,
                            ArrayList<String> images) {
        this.context = context;
        this.ids = ids;
        this.names = names;
        this.prices = prices;
        this.descs = descs;
        this.images = images;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup p, int v) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_my_product, p, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int i) {

        h.name.setText(names.get(i));
        h.price.setText("₹ " + prices.get(i));

        try {
            h.img.setImageURI(Uri.parse(images.get(i)));
        } catch (Exception e) {
            h.img.setImageResource(android.R.drawable.ic_menu_gallery);
        }

        DBHelper db = new DBHelper(context);

        // DELETE
        h.delete.setOnClickListener(v -> {
            db.deleteProduct(ids.get(i));
            Toast.makeText(context, "Deleted", Toast.LENGTH_SHORT).show();
            ((MyProductsActivity)context).recreate();
        });

        // EDIT
        h.edit.setOnClickListener(v -> {
            Intent intent = new Intent(context, EditProductActivity.class);
            intent.putExtra("id", ids.get(i));
            intent.putExtra("name", names.get(i));
            intent.putExtra("price", prices.get(i));
            intent.putExtra("desc", descs.get(i));
            intent.putExtra("image", images.get(i));
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return names.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView img;
        TextView name, price;
        Button edit, delete;

        public ViewHolder(@NonNull View v) {
            super(v);

            img = v.findViewById(R.id.img);
            name = v.findViewById(R.id.name);
            price = v.findViewById(R.id.price);
            edit = v.findViewById(R.id.btnEdit);
            delete = v.findViewById(R.id.btnDelete);
        }
    }
}