package com.example.unitrade;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class SettingsActivity extends AppCompatActivity {

    Button language, logout;
    Switch themeSwitch;

    @Override
    protected void attachBaseContext(Context newBase) {
        String lang = LocaleHelper.getLanguage(newBase);
        super.attachBaseContext(LocaleHelper.setLocale(newBase, lang));
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_settings);

        language = findViewById(R.id.btnLanguage);
        logout = findViewById(R.id.btnLogout);
        themeSwitch = findViewById(R.id.switchTheme);

        SharedPreferences prefs = getSharedPreferences("Settings", MODE_PRIVATE);

        // LOAD THEME
        boolean isDark = prefs.getBoolean("dark", false);
        themeSwitch.setChecked(isDark);

        if (isDark) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }

        // LANGUAGE CHANGE
        language.setOnClickListener(v -> {

            String[] langs = {"English", "Hindi"};

            new AlertDialog.Builder(this)
                    .setTitle("Select Language")
                    .setItems(langs, (d, which) -> {

                        if (which == 0) {
                            LocaleHelper.saveLanguage(this, "en");
                        } else {
                            LocaleHelper.saveLanguage(this, "hi");
                        }

                        // RESTART APP
                        Intent intent = new Intent(this, LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    })
                    .show();
        });

        // DARK MODE
        themeSwitch.setOnCheckedChangeListener((btn, isChecked) -> {

            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("dark", isChecked);
            editor.apply();

            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            }
        });

        // LOGOUT
        logout.setOnClickListener(v -> {
            new SessionManager(this).logout();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }
}