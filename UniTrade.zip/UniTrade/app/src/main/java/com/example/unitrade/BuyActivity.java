package com.example.unitrade;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class BuyActivity extends AppCompatActivity {

    ListView listView;
    Spinner filter;

    DBHelper db;

    ArrayList<String> names = new ArrayList<>();
    ArrayList<String> prices = new ArrayList<>();
    ArrayList<String> descs = new ArrayList<>();
    ArrayList<String> sellers = new ArrayList<>();

    @Override
    protected void attachBaseContext(Context newBase) {
        String lang = LocaleHelper.getLanguage(newBase);
        super.attachBaseContext(LocaleHelper.setLocale(newBase, lang));
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_buy);

        listView = findViewById(R.id.listView);
        filter = findViewById(R.id.spFilter);

        db = new DBHelper(this);

        // CATEGORY FILTER
        String[] cats = {"All", "Electronics", "Books", "Clothes", "Furniture", "Sports", "Other"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                cats
        );
        filter.setAdapter(adapter);

        // LOAD ON SELECT
        filter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                loadProducts(cats[pos]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // ITEM CLICK → OPEN DETAILS
        listView.setOnItemClickListener((parent, view, position, id) -> {

            Intent i = new Intent(this, ProductDetailsActivity.class);

            i.putExtra("name", names.get(position));
            i.putExtra("price", prices.get(position));
            i.putExtra("desc", descs.get(position));
            i.putExtra("seller", sellers.get(position)); // 🔥 IMPORTANT FOR CHAT

            startActivity(i);
        });
    }

    private void loadProducts(String category) {

        names.clear();
        prices.clear();
        descs.clear();
        sellers.clear();

        Cursor c = db.getProductsByCategory(category);

        if (c.moveToFirst()) {
            do {
                sellers.add(c.getString(1)); // email
                names.add(c.getString(2));   // name
                prices.add(c.getString(3));  // price
                descs.add(c.getString(4));   // description
            } while (c.moveToNext());
        }

        listView.setAdapter(new ProductListAdapter(this, names, prices));
    }
}