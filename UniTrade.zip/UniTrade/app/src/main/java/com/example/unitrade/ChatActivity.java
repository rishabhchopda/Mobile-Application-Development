package com.example.unitrade;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.*;

public class ChatActivity extends AppCompatActivity {

    ListView listView;
    EditText message;
    Button send;

    DBHelper db;
    SessionManager session;

    ArrayList<String> chats = new ArrayList<>();
    String otherUser;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_chat);

        listView = findViewById(R.id.listView);
        message = findViewById(R.id.etMessage);
        send = findViewById(R.id.btnSend);

        db = new DBHelper(this);
        session = new SessionManager(this);

        otherUser = getIntent().getStringExtra("user");

        loadChat();

        send.setOnClickListener(v -> {

            String msg = message.getText().toString().trim();
            if (msg.isEmpty()) return;

            String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());

            db.sendMessage(session.getEmail(), otherUser, msg, time);

            message.setText("");
            loadChat();
        });
    }

    private void loadChat() {

        chats.clear();

        Cursor c = db.getChat(session.getEmail(), otherUser);

        if (c.moveToFirst()) {
            do {
                String sender = c.getString(1);
                String msg = c.getString(3);
                String time = c.getString(4);

                chats.add(sender + ":\n" + msg + " (" + time + ")");

            } while (c.moveToNext());
        }

        listView.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, chats));
    }
}