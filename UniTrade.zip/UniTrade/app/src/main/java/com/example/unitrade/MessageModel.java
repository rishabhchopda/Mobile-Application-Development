package com.example.unitrade;

public class MessageModel {

    String sender, message, time;

    public MessageModel(String s, String m, String t) {
        sender = s;
        message = m;
        time = t;
    }
}