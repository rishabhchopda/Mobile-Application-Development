package com.example.unitrade;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.*;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder> {

    Context context;
    ArrayList<String> names, prices, descs, images, sellers;

    public ProductAdapter(Context context,
                          ArrayList<String> names,
                          ArrayList<String> prices,
                          ArrayList<String> descs,
                          ArrayList<String> images,
                          ArrayList<String> sellers) {

        this.context = context;
        this.names = names;
        this.prices = prices;
        this.descs = descs;
        this.images = images;
        this.sellers = sellers;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int i) {

        h.name.setText(names.get(i));
        h.price.setText("₹ " + prices.get(i));
        h.desc.setText(descs.get(i));

        try {
            h.image.setImageURI(Uri.parse(images.get(i)));
        } catch (Exception e) {
            h.image.setImageResource(android.R.drawable.ic_menu_gallery);
        }

        h.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ProductDetailsActivity.class);
            intent.putExtra("name", names.get(i));
            intent.putExtra("price", prices.get(i));
            intent.putExtra("desc", descs.get(i));
            intent.putExtra("image", images.get(i));
            intent.putExtra("seller", sellers.get(i));
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return names.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView name, price, desc;
        ImageView image;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            name = itemView.findViewById(R.id.tvName);
            price = itemView.findViewById(R.id.tvPrice);
            desc = itemView.findViewById(R.id.tvDesc);
            image = itemView.findViewById(R.id.imgProduct);
        }
    }
}