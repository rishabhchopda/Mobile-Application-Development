package com.example.unitrade;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {

    SharedPreferences prefs;
    SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        prefs = context.getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    // CREATE SESSION
    public void createSession(String email) {
        editor.putString("email", email);
        editor.apply();
    }

    // GET EMAIL
    public String getEmail() {
        return prefs.getString("email", null);
    }

    // LOGOUT
    public void logout() {
        editor.clear();
        editor.apply();
    }
}