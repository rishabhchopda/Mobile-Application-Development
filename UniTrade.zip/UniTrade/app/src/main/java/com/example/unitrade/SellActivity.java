package com.example.unitrade;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class SellActivity extends AppCompatActivity {

    ImageView img;
    EditText name, price, desc;
    Spinner category;
    Button upload, select;

    String imagePath = "";
    int PICK = 1;

    DBHelper db;
    SessionManager session;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_sell);

        img = findViewById(R.id.productImage);
        name = findViewById(R.id.etProductName);
        price = findViewById(R.id.etPrice);
        desc = findViewById(R.id.etDescription);
        category = findViewById(R.id.spCategory);
        upload = findViewById(R.id.btnUpload);
        select = findViewById(R.id.btnSelectImage);

        db = new DBHelper(this);
        session = new SessionManager(this);

        // ✅ CATEGORY OPTIONS (VISIBLE IN DROPDOWN)
        String[] categories = {
                "Electronics",
                "Books",
                "Clothes",
                "Furniture",
                "Sports",
                "Other"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                categories
        );

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category.setAdapter(adapter);

        // IMAGE PICK
        select.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            startActivityForResult(i, PICK);
        });

        // UPLOAD
        upload.setOnClickListener(v -> {

            if (name.getText().toString().isEmpty() || imagePath.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean res = db.insertProduct(
                    session.getEmail(),
                    name.getText().toString(),
                    price.getText().toString(),
                    desc.getText().toString(),
                    category.getSelectedItem().toString(), // selected category
                    imagePath
            );

            if (res) {
                Toast.makeText(this, "Product Uploaded", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);

        if (r == PICK && c == RESULT_OK && d != null) {
            Uri uri = d.getData();
            img.setImageURI(uri);
            imagePath = uri.toString();
        }
    }
}