package com.example.unitrade;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProductDetailsActivity extends AppCompatActivity {

    TextView name, price, desc;
    Button contact;

    String sellerEmail;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_product_details);

        name = findViewById(R.id.tvName);
        price = findViewById(R.id.tvPrice);
        desc = findViewById(R.id.tvDesc);
        contact = findViewById(R.id.btnContact);

        // GET DATA
        name.setText(getIntent().getStringExtra("name"));
        price.setText(getIntent().getStringExtra("price"));
        desc.setText(getIntent().getStringExtra("desc"));
        sellerEmail = getIntent().getStringExtra("seller");

        // CONTACT SELLER
        contact.setOnClickListener(v -> {

            Intent i = new Intent(this, ChatActivity.class);
            i.putExtra("user", sellerEmail);
            startActivity(i);
        });
    }
}